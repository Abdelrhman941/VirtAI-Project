/* NOTE: patched excerpt of CircuitBoardBackground.tsx.
   Only the JSX return block was modified to move static positioning to
   Tailwind classes. The (~600 lines of) canvas drawing logic above is UNCHANGED
   from the current source and must be kept as-is in the real file.

   👉 In your repo, keep everything above `return (` intact, and REPLACE only
   the `return (…)` block with the version below. This file is provided so you
   can copy-paste the block precisely. */

// ---------------------------- REPLACE THIS BLOCK ONLY ----------------------------
//   return (
//     <canvas
//       ref={canvasRef}
//       className={className}
//       style={{
//         position: 'fixed',
//         top: 0,
//         left: 0,
//         width: '100vw',
//         height: '100vh',
//         zIndex: 0,
//         pointerEvents: 'none',
//         opacity,
//       }}
//       aria-hidden="true"
//     />
//   );
// }
// ------------------------------ WITH THIS BLOCK ----------------------------------

/*
  return (
    <canvas
      ref={canvasRef}
      // Static positioning → Tailwind classes. `opacity` remains inline because it is
      // a dynamic prop and driven by scroll state elsewhere in the component tree.
      className={`fixed top-0 left-0 w-screen h-screen z-0 pointer-events-none ${className ?? ''}`}
      style={{ opacity }}
      aria-hidden="true"
    />
  );
}
*/
