/* NOTE: patched excerpt of widgets/Overview/Navbar.tsx.
   Only the desktop-nav link block changes (color logic moves out of inline style
   into a `cn()` conditional class). Everything above and below the marked block
   stays as-is in the current source. */

// -------------------------- REPLACE THIS BLOCK ONLY --------------------------
// {NAV_ITEMS.map(({ label, target }) => (
//   <li key={target}>
//     <a
//       href={`#${target}`}
//       onClick={(e) => { e.preventDefault(); scrollTo(target); }}
//       className="relative block cursor-pointer px-1 py-2 text-sm font-medium tracking-wide transition-colors duration-200 font-display focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-dark rounded-md"
//       style={{
//         color: activeId === target ? '#B4AB8B' : '#f5f1ec',
//       }}
//     >
//       {label}
//       …
//     </a>
//   </li>
// ))}
// ----------------------------- WITH THIS BLOCK -------------------------------

/*
import { cn } from '@/shared/utils/cn';

…

{NAV_ITEMS.map(({ label, target }) => (
  <li key={target}>
    <a
      href={`#${target}`}
      onClick={(e) => { e.preventDefault(); scrollTo(target); }}
      className={cn(
        'relative block cursor-pointer px-1 py-2 text-sm font-medium tracking-wide transition-colors duration-200 font-display focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-dark rounded-md',
        activeId === target ? 'text-gold-soft' : 'text-offwhite',
      )}
    >
      {label}
      {activeId === target && (
        <motion.span
          layoutId="nav-underline"
          className="absolute bottom-0 left-0 h-0.5 w-full rounded-full bg-gold"
          transition={{ type: 'tween', ease: [0.2, 0.8, 0.2, 1], duration: 0.3 }}
        />
      )}
    </a>
  </li>
))}
*/
