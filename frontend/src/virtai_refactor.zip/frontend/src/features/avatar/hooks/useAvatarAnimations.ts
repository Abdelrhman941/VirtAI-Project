/**
 * MOVED FILE
 * Old path : frontend/src/features/avatar/components/useAvatarAnimations.ts
 * New path : frontend/src/features/avatar/hooks/useAvatarAnimations.ts
 *
 * Keep this shim while migrating imports, then delete both this stub AND the
 * legacy `components/useAvatarAnimations.ts` file. See MIGRATION.md.
 */
export * from '../components/useAvatarAnimations';
