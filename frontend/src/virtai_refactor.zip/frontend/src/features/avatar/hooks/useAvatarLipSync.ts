/**
 * MOVED FILE
 * Old path : frontend/src/features/avatar/components/useAvatarLipSync.ts
 * New path : frontend/src/features/avatar/hooks/useAvatarLipSync.ts
 * See MIGRATION.md for the follow-up cleanup.
 */
export * from '../components/useAvatarLipSync';
