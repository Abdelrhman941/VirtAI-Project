/**
 * MOVED FILE — see documentApi.ts (same batch).
 * Old path : frontend/src/features/documents/types.ts
 * New path : frontend/src/features/documents/types/index.ts
 */
export * from '../types';
