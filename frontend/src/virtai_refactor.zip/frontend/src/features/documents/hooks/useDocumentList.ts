/**
 * MOVED FILE — see documentApi.ts (same batch).
 * Old path : frontend/src/features/documents/useDocumentList.ts
 * New path : frontend/src/features/documents/hooks/useDocumentList.ts
 */
export * from '../useDocumentList';
