/**
 * MOVED FILE
 * ==========
 * Old path : frontend/src/features/documents/documentApi.ts        (root of feature)
 * New path : frontend/src/features/documents/api/documentApi.ts    (this file)
 *
 * The file body is IDENTICAL to the current version — this placeholder is
 * shipped so you can `git mv` it to the new location, then confirm imports
 * still resolve. See MIGRATION.md for the full grep-and-replace instructions.
 */
export * from '../documentApi';
