/* NOTE: patched excerpt of pages/AvatarPlayground.tsx (now moved into a folder).
   Only two static inline styles change; everything else stays as-is.

   IMPORTANT MOVE:
     old path → frontend/src/pages/AvatarPlayground.tsx
     new path → frontend/src/pages/AvatarPlayground/index.tsx
   Update whichever router import references the old path (see MIGRATION.md). */

// -------------------------- REPLACE THIS BLOCK ONLY --------------------------
// <div ref={timelineCursorRef}
//      className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
//      style={{ left: '0%' }} />
// ----------------------------- WITH THIS BLOCK -------------------------------

/*
<div ref={timelineCursorRef}
     className="absolute top-0 bottom-0 left-0 w-0.5 bg-red-500 z-10" />
*/

// The viseme timeline segments MUST keep their inline styles because
// `left` and `width` are dynamic (percentage derived from `v.start / v.end`).
// Do not attempt to convert those to Tailwind classes.
